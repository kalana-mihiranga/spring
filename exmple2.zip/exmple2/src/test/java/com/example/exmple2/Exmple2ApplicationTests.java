package com.example.exmple2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exmple2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
